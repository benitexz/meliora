<?php
$conn = new mysqli("localhost","root","","db_sekolah");

// ================== SIMPAN ==================
if(isset($_POST['simpan'])){
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $ttl = $_POST['ttl'];
    $wali = $_POST['wali'];

    $conn->query("INSERT INTO student_profile (nama,kelas,ttl,wali)
                  VALUES ('$nama','$kelas','$ttl','$wali')");

    header("Location: students.php"); exit;
}

// ================== HAPUS ==================
if(isset($_GET['hapus'])){
    $id = intval($_GET['hapus']);
    $conn->query("DELETE FROM student_profile WHERE id=$id");
    header("Location: students.php"); exit;
}

// ================== EDIT ==================
$edit = null;
if(isset($_GET['edit'])){
    $id = intval($_GET['edit']);
    $edit = $conn->query("SELECT * FROM student_profile WHERE id=$id")->fetch_assoc();
}

// ================== UPDATE ==================
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $ttl = $_POST['ttl'];
    $wali = $_POST['wali'];

    $conn->query("UPDATE student_profile 
                  SET nama='$nama', kelas='$kelas', ttl='$ttl', wali='$wali'
                  WHERE id=$id");

    header("Location: students.php"); exit;
}

// ================== DATA ==================
$data = $conn->query("SELECT * FROM student_profile ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Students</title>

<style>
body{font-family:Segoe UI;background:#f3f5fa;margin:0;}
.main{padding:30px;}
.card{background:white;padding:25px;border-radius:20px;}

table{
width:100%;
border-collapse:collapse;
margin-top:20px;
}

th,td{
padding:12px;
border-bottom:1px solid #eee;
text-align:left;
}

th{
background:#f5f7fb;
}

.btn{
padding:6px 12px;
border-radius:8px;
text-decoration:none;
font-size:12px;
}

.btn-view{background:#2f67d8;color:white;}
.btn-edit{background:#f1c40f;color:white;}
.btn-del{background:#e74c3c;color:white;}

input{
padding:10px;
margin:5px;
border-radius:10px;
border:1px solid #ddd;
}

button{
background:#2f67d8;
color:white;
padding:10px 20px;
border:none;
border-radius:10px;
cursor:pointer;
}
</style>
</head>

<body>

<div class="main">

<h1>Data Siswa</h1>

<div class="card">

<!-- FORM -->
<form method="POST">

<input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">

<input type="text" name="nama" placeholder="Nama Siswa"
value="<?= $edit['nama'] ?? '' ?>" required>

<input type="text" name="kelas" placeholder="Kelas"
value="<?= $edit['kelas'] ?? '' ?>" required>

<input type="text" name="ttl" placeholder="Tanggal Lahir"
value="<?= $edit['ttl'] ?? '' ?>" required>

<input type="text" name="wali" placeholder="Wali Murid"
value="<?= $edit['wali'] ?? '' ?>" required>

<?php if($edit): ?>
<button name="update">Update</button>
<?php else: ?>
<button name="simpan">Tambah</button>
<?php endif; ?>

</form>

<!-- TABLE -->
<table>

<tr>
<th>Nama</th>
<th>Kelas</th>
<th>Wali</th>
<th>Aksi</th>
</tr>

<?php while($row = $data->fetch_assoc()): ?>
<tr>
<td><?= $row['nama'] ?></td>
<td><?= $row['kelas'] ?></td>
<td><?= $row['wali'] ?></td>
<td>

<a class="btn btn-view" 
href="?p=student&id=<?= $row['id'] ?>">
Profil
</a>

<a class="btn btn-edit" 
href="?edit=<?= $row['id'] ?>">
Edit
</a>

<a class="btn btn-del" 
href="?hapus=<?= $row['id'] ?>" 
onclick="return confirm('Hapus?')">
Hapus
</a>

</td>
</tr>
<?php endwhile; ?>

</table>

</div>

</div>

</body>
</html>