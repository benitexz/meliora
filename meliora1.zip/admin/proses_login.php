<?php
include("../db.php");

$username=$_REQUEST['username'];
$pass=$_REQUEST['password'];

        if($username!=''& $pass!='')
        {
            $sql= "SELECT * FROM user u where u.username='$username' AND u.password='$pass'";
            $result = mysqli_query($conn,$sql);
            $hasil= mysqli_fetch_array($result);
            
            if($hasil['username']==$username && $hasil['password']==$pass)
            {
                //kebun
                    
                    if($hasil['status']=='admin')
                    {
                        session_start();
                        $_SESSION['pengguna']=$hasil['username'];
                        $_SESSION['id_user']=$hasil['id_user'];
                        $_SESSION['admin']=$hasil['status'];
                        $d=date("Y-m-d");
                        //$k=mysqli_query($conn,"insert into log_history (username,ip,tgl_log) values ('$username','$h','$d')");
                        ?>
                        <?php
                        header ("location:index.php");
                    }
                    
                    
            }           
            else
            {
                ?>
                <script type="text/javascript">
                <!--
                alert("Login Anda Salah")
                window.location = "login.php";
                //-->
                </script>
                <?php
            }
        }
        else
        {
            ?>
            <script type="text/javascript">
            <!--
            alert("Please Login First")
            window.location = "index.php";
            //-->
            </script>
            <?php
            
        }




