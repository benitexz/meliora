<?php
include "../db.php";

// ================== SIMPAN ==================
if(isset($_POST['simpan'])){
    $nama = $_POST['nama'];
    $kategori = $_POST['kategori'];
    $catatan = $_POST['catatan'];
    $tanggal = date('Y-m-d');

    $conn->query("INSERT INTO perkembangan (nama,kategori,catatan,tanggal)
                  VALUES ('$nama','$kategori','$catatan','$tanggal')");

    header("Location: perkembangan.php"); exit;
}

// ================== HAPUS ==================
if(isset($_GET['hapus'])){
    $id = intval($_GET['hapus']);
    $conn->query("DELETE FROM perkembangan WHERE id=$id");
    header("Location: perkembangan.php"); exit;
}

// ================== EDIT ==================
$edit = null;
if(isset($_GET['edit'])){
    $id = intval($_GET['edit']);
    $res = $conn->query("SELECT * FROM perkembangan WHERE id=$id");
    $edit = $res->fetch_assoc();
}

// ================== UPDATE ==================
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $kategori = $_POST['kategori'];
    $catatan = $_POST['catatan'];

    $conn->query("UPDATE perkembangan 
                  SET nama='$nama', kategori='$kategori', catatan='$catatan'
                  WHERE id=$id");

    header("Location: perkembangan.php"); exit;
}

// ================== DATA PERKEMBANGAN ==================
$data = $conn->query("SELECT * FROM perkembangan ORDER BY id DESC");

// ================== DATA SISWA (DATABASE) ==================
$siswa_list = $conn->query("SELECT id, nama FROM student_profile ORDER BY nama ASC");
$siswa_form = $conn->query("SELECT id, nama FROM student_profile ORDER BY nama ASC");

// ================== KATEGORI ==================
$kategoriList = [
"Agama & Moral","Sosial Emosional","Bahasa",
"Kognitif","Fisik Motorik","Seni"
];
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Child Development</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Segoe UI;}
body{display:flex;background:#f0f2f6;}
.main{flex:1;padding:30px;}
.topbar{display:flex;justify-content:space-between;margin-bottom:25px;}
.container{background:white;padding:25px;border-radius:20px;}
.content{display:flex;gap:25px;}

/* SIDEBAR SISWA */
.student-list{
width:260px;
border:1px solid #e4e7f2;
padding:20px;
border-radius:20px;
background:white;
}

.student{
padding:12px;
border:1px solid #e4e7f2;
border-radius:12px;
margin-bottom:10px;
cursor:pointer;
}

.student:hover{
border-color:#2d6cdf;
}

/* FORM */
.form-area{
flex:1;
border:1px solid #e4e7f2;
padding:25px;
border-radius:20px;
background:white;
}

/* SELECT */
select{
width:100%;
padding:12px;
border-radius:12px;
border:1px solid #dfe3ef;
margin-bottom:15px;
}

textarea{
width:100%;
height:120px;
padding:15px;
border-radius:15px;
border:1px solid #dfe3ef;
margin-bottom:15px;
}

.btn-simpan{
background:#2d6cdf;
color:white;
border:none;
padding:12px 40px;
border-radius:25px;
cursor:pointer;
}

/* DATA */
.data{
margin-top:20px;
}

.item{
border:1px solid #ddd;
padding:12px;
margin-bottom:10px;
border-radius:10px;
background:#fafbff;
}

a{
font-size:12px;
color:#2d6cdf;
text-decoration:none;
}
</style>

</head>

<body>

<div class="main">

<div class="topbar">
<h1>Child Development</h1>
<span>Kepala Sekolah</span>
</div>

<div class="container">

<h2>Pencatatan Perkembangan Anak</h2>

<div class="content">

<!-- LIST SISWA -->
<div class="student-list">
<h3>Daftar Siswa</h3>

<?php while($s = $siswa_list->fetch_assoc()): ?>
<div class="student">
<?= $s['nama'] ?>
</div>
<?php endwhile; ?>

</div>

<!-- FORM -->
<div class="form-area">

<h3>Input Catatan</h3>

<form method="POST">

<input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">

<label>Nama Siswa</label>
<select name="nama" required>

<option value="">-- Pilih Siswa --</option>

<?php while($s = $siswa_form->fetch_assoc()): ?>
<option value="<?= $s['nama'] ?>"
<?= ($edit['nama'] ?? '') == $s['nama'] ? 'selected' : '' ?>>
<?= $s['nama'] ?>
</option>
<?php endwhile; ?>

</select>

<label>Kategori</label>
<select name="kategori" required>

<option value="">-- Pilih Kategori --</option>

<?php foreach($kategoriList as $k): ?>
<option value="<?= $k ?>"
<?= ($edit['kategori'] ?? '') == $k ? 'selected' : '' ?>>
<?= $k ?>
</option>
<?php endforeach; ?>

</select>

<label>Catatan</label>
<textarea name="catatan"><?= $edit['catatan'] ?? '' ?></textarea>

<?php if($edit): ?>
<button class="btn-simpan" name="update">Update</button>
<?php else: ?>
<button class="btn-simpan" name="simpan">Simpan</button>
<?php endif; ?>

</form>

<!-- DATA -->
<div class="data">
<h3>Data Tersimpan</h3>

<?php while($row = $data->fetch_assoc()): ?>
<div class="item">
<b><?= $row['nama'] ?></b> - <?= $row['kategori'] ?><br>
<?= $row['catatan'] ?><br>
<small><?= $row['tanggal'] ?></small><br>

<a href="?edit=<?= $row['id'] ?>">Edit</a> |
<a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Hapus data?')">Hapus</a>
</div>
<?php endwhile; ?>

</div>

</div>

</div>

</div>

</div>

</body>
</html>