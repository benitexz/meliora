<?php
include "../db.php";

// ================== SIMPAN ==================
if(isset($_POST['simpan'])){
    $judul = $_POST['judul'];
    $tanggal = $_POST['tanggal'];
    $pembahasan = $_POST['pembahasan'];
    $kesimpulan = $_POST['kesimpulan'];

    $conn->query("INSERT INTO meeting_notes (judul,tanggal,pembahasan,kesimpulan)
                  VALUES ('$judul','$tanggal','$pembahasan','$kesimpulan')");

    header("Location: meeting_notes.php"); exit;
}

// ================== HAPUS ==================
if(isset($_GET['hapus'])){
    $id = intval($_GET['hapus']);
    $conn->query("DELETE FROM meeting_notes WHERE id=$id");
    header("Location: meeting_notes.php"); exit;
}

// ================== EDIT ==================
$edit = null;
if(isset($_GET['edit'])){
    $id = intval($_GET['edit']);
    $edit = $conn->query("SELECT * FROM meeting_notes WHERE id=$id")->fetch_assoc();
}

// ================== UPDATE ==================
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $judul = $_POST['judul'];
    $tanggal = $_POST['tanggal'];
    $pembahasan = $_POST['pembahasan'];
    $kesimpulan = $_POST['kesimpulan'];

    $conn->query("UPDATE meeting_notes SET 
        judul='$judul',
        tanggal='$tanggal',
        pembahasan='$pembahasan',
        kesimpulan='$kesimpulan'
        WHERE id=$id");

    header("Location: meeting_notes.php"); exit;
}

// ================== DATA ==================
$data = $conn->query("SELECT * FROM meeting_notes ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Meeting Notes</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Segoe UI;}
body{background:#f4f6fb;}

.main{padding:30px;}

.header{display:flex;justify-content:space-between;margin-bottom:20px;}

.container{background:white;padding:25px;border-radius:20px;}

.content{display:flex;gap:25px;margin-top:20px;}

/* LIST */
.list{
width:260px;
border:1px solid #e5e9f2;
border-radius:15px;
padding:20px;
background:white;
}

.meeting{
border:1px solid #d9e0ef;
padding:12px;
border-radius:10px;
margin-bottom:10px;
cursor:pointer;
}

.meeting:hover{
border-color:#2f67d8;
}

/* DETAIL */
.detail{
flex:1;
border:1px solid #e5e9f2;
border-radius:15px;
padding:20px;
background:white;
}

.note-box{
border:1px solid #e1e5f0;
border-radius:12px;
padding:15px;
margin-top:10px;
line-height:1.6;
}

/* FORM */
input,textarea{
width:100%;
padding:10px;
margin:5px 0;
border-radius:10px;
border:1px solid #ddd;
}

textarea{height:100px;}

/* BUTTON */
.actions{
display:flex;
justify-content:flex-end;
gap:10px;
margin-top:15px;
}

.btn{
padding:10px 20px;
border-radius:10px;
border:none;
cursor:pointer;
}

.primary{background:#2f67d8;color:white;}
.outline{border:1px solid #2f67d8;background:white;color:#2f67d8;}

.add-btn{
background:#2f67d8;
color:white;
padding:10px 18px;
border:none;
border-radius:10px;
cursor:pointer;
}
a{font-size:12px;color:#2f67d8;text-decoration:none;}
</style>

</head>

<body>

<div class="main">

<div class="header">
<h1>Meeting Notes</h1>
<span>Guru Kelas K2</span>
</div>

<div class="container">

<h2>Arsip Notulen Rapat</h2>

<div class="content">

<!-- LIST -->
<div class="list">
<h3>Daftar Rapat</h3>

<?php while($row = $data->fetch_assoc()): ?>
<div class="meeting">
<?= $row['judul'] ?><br>
<small><?= $row['tanggal'] ?></small><br>

<a href="?edit=<?= $row['id'] ?>">Edit</a> |
<a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
</div>
<?php endwhile; ?>

</div>

<!-- DETAIL / FORM -->
<div class="detail">

<h3>Editor Notulen</h3>

<form method="POST">

<input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">

<label>Judul</label>
<input type="text" name="judul" value="<?= $edit['judul'] ?? '' ?>" required>

<label>Tanggal</label>
<input type="date" name="tanggal" value="<?= $edit['tanggal'] ?? '' ?>" required>

<label>Pembahasan</label>
<textarea name="pembahasan"><?= $edit['pembahasan'] ?? '' ?></textarea>

<label>Kesimpulan</label>
<textarea name="kesimpulan"><?= $edit['kesimpulan'] ?? '' ?></textarea>

<div class="actions">

<?php if($edit): ?>
<button class="btn primary" name="update">Update</button>
<?php else: ?>
<button class="btn primary" name="simpan">Simpan</button>
<?php endif; ?>

<button type="button" class="btn outline">Export</button>

</div>

</form>

</div>

</div>

</div>

</div>

</body>
</html>