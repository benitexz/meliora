<?php
include "../db.php";

// ================== SIMPAN ==================
if(isset($_POST['simpan'])){
    $tema = $_POST['tema'];
    $subtema = $_POST['subtema'];
    $tujuan = $_POST['tujuan'];
    $kegiatan = $_POST['kegiatan'];
    $asesmen = $_POST['asesmen'];

    $conn->query("INSERT INTO lesson_plan (tema,subtema,tujuan,kegiatan,asesmen)
                  VALUES ('$tema','$subtema','$tujuan','$kegiatan','$asesmen')");

    header("Location: lesson_plan.php"); exit;
}

// ================== HAPUS ==================
if(isset($_GET['hapus'])){
    $id = intval($_GET['hapus']);
    $conn->query("DELETE FROM lesson_plan WHERE id=$id");
    header("Location: lesson_plan.php"); exit;
}

// ================== EDIT ==================
$edit = null;
if(isset($_GET['edit'])){
    $id = intval($_GET['edit']);
    $edit = $conn->query("SELECT * FROM lesson_plan WHERE id=$id")->fetch_assoc();
}

// ================== UPDATE ==================
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $tema = $_POST['tema'];
    $subtema = $_POST['subtema'];
    $tujuan = $_POST['tujuan'];
    $kegiatan = $_POST['kegiatan'];
    $asesmen = $_POST['asesmen'];

    $conn->query("UPDATE lesson_plan SET 
        tema='$tema',
        subtema='$subtema',
        tujuan='$tujuan',
        kegiatan='$kegiatan',
        asesmen='$asesmen'
        WHERE id=$id");

    header("Location: lesson_plan.php"); exit;
}

// ================== DATA ==================
$data = $conn->query("SELECT * FROM lesson_plan ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Lesson Plan</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial;}

body{background:#f4f6fb;}

.container{display:flex;}

/* MAIN */
.main{flex:1;padding:20px;}

.header{display:flex;justify-content:space-between;margin-bottom:20px;}

.content{display:flex;gap:20px;}

.card{background:#fff;padding:20px;border-radius:15px;}

/* LEFT */
.left{width:30%;}

.module{
background:#f5f7fb;
padding:15px;
border-radius:10px;
margin-top:15px;
}

.module a{
text-decoration:none;
color:#2f4db6;
font-size:12px;
}

/* RIGHT */
.right{width:70%;}

label{
display:block;
margin-top:15px;
margin-bottom:5px;
font-weight:bold;
}

input,textarea{
width:100%;
padding:10px;
border-radius:8px;
border:1px solid #ccc;
}

textarea{height:80px;}

/* BUTTON */
.button-group{
margin-top:20px;
display:flex;
gap:10px;
}

.btn{
padding:10px 20px;
border-radius:8px;
border:none;
cursor:pointer;
}

.primary{
background:#2f4db6;
color:white;
}

.outline{
border:1px solid #2f4db6;
color:#2f4db6;
background:transparent;
}
</style>

</head>

<body>

<div class="container">

<div class="main">

<div class="header">
<h1>Lesson Plan</h1>
<span>Kepala Sekolah</span>
</div>

<div class="content">

<!-- LEFT LIST -->
<div class="card left">

<h3>Daftar Modul Ajar</h3>

<?php while($row = $data->fetch_assoc()): ?>
<div class="module">
<b><?= $row['tema'] ?></b><br>
<p><?= $row['subtema'] ?></p>

<span>
<a href="?edit=<?= $row['id'] ?>">Edit</a> |
<a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
</span>
</div>
<?php endwhile; ?>

</div>

<!-- RIGHT FORM -->
<div class="card right">

<h3>Editor Modul Ajar</h3>

<form method="POST">

<input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">

<label>Tema</label>
<input type="text" name="tema" value="<?= $edit['tema'] ?? '' ?>" required>

<label>Subtema</label>
<input type="text" name="subtema" value="<?= $edit['subtema'] ?? '' ?>" required>

<label>Tujuan Pembelajaran</label>
<textarea name="tujuan"><?= $edit['tujuan'] ?? '' ?></textarea>

<label>Kegiatan</label>
<textarea name="kegiatan"><?= $edit['kegiatan'] ?? '' ?></textarea>

<label>Asesmen</label>
<textarea name="asesmen"><?= $edit['asesmen'] ?? '' ?></textarea>

<div class="button-group">

<?php if($edit): ?>
<button class="btn primary" name="update">Update</button>
<?php else: ?>
<button class="btn primary" name="simpan">Simpan</button>
<?php endif; ?>

<button class="btn outline" type="button">Export</button>

</div>

</form>

</div>

</div>

</div>

</div>

</body>
</html>