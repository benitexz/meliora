<?php

include "../db.php";

// ================== CREATE & UPDATE ==================
if(isset($_POST['simpan'])){
    $id = $_POST['id'];
    $target = $_POST['target'];
    $indikator = $_POST['indikator'];
    $waktu = $_POST['waktu'];

    if($id == ""){
        $sql = "INSERT INTO annual_plan (target, indikator, waktu)
                VALUES ('$target','$indikator','$waktu')";
    } else {
        $sql = "UPDATE annual_plan 
                SET target='$target', indikator='$indikator', waktu='$waktu'
                WHERE id=".intval($id);
    }

    if(!$conn->query($sql)){
        die("Error: ".$conn->error);
    }

    header("Location: annual_plan.php");
    exit;
}

// ================== DELETE ==================
if(isset($_GET['hapus'])){
    $id = intval($_GET['hapus']);

    if(!$conn->query("DELETE FROM annual_plan WHERE id=$id")){
        die("Error: ".$conn->error);
    }

    header("Location: annual_plan.php");
    exit;
}

// ================== EDIT ==================
$edit = null;
if(isset($_GET['edit'])){
    $id = intval($_GET['edit']);
    $result = $conn->query("SELECT * FROM annual_plan WHERE id=$id");
    $edit = $result->fetch_assoc();
}

// ================== READ ==================
$data = $conn->query("SELECT * FROM annual_plan ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Annual Plan</title>

<style>
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Segoe UI, sans-serif;
}

body{
display:flex;
background:#f2f4f9;
}

/* MAIN */
.main{
flex:1;
padding:30px;
}

/* TOPBAR */
.topbar{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:20px;
}

.topbar h1{
color:#1c2c4c;
}

/* CARD */
.card{
background:white;
padding:25px;
border-radius:20px;
box-shadow:0 2px 8px rgba(0,0,0,0.05);
}

.card h2{
margin-bottom:20px;
}

/* CONTENT */
.content{
display:flex;
gap:25px;
}

/* LEFT */
.left{
width:250px;
border:1px solid #e4e7f0;
border-radius:15px;
padding:20px;
}

.year-box{
border:1px solid #d9deea;
padding:12px;
border-radius:10px;
margin:10px 0 20px 0;
color:#2f67d8;
font-weight:600;
text-align:center;
}

/* RIGHT */
.right{
flex:1;
border:1px solid #e4e7f0;
border-radius:15px;
padding:20px;
}

/* TABLE */
.table{
margin-top:15px;
}

.row{
display:grid;
grid-template-columns:1fr 2fr 1fr 1fr;
gap:10px;
padding:15px;
border:1px solid #e4e7f0;
border-radius:12px;
margin-bottom:10px;
}

.header{
background:#f5f7fb;
font-weight:bold;
}

.blue{
color:#2f67d8;
font-weight:600;
}

/* FORM */
form input{
padding:10px;
margin:5px;
border-radius:8px;
border:1px solid #ddd;
}

/* BUTTON */
.btn-area{
text-align:right;
margin-top:20px;
}

button{
background:#2f67d8;
color:white;
border:none;
padding:12px 30px;
border-radius:12px;
cursor:pointer;
}

button:hover{
background:#1e4fbf;
}

a{
font-size:12px;
color:#2f67d8;
text-decoration:none;
}

/* RESPONSIVE */
@media (max-width:768px){
.content{
flex-direction:column;
}
.left{
width:100%;
}
.row{
grid-template-columns:1fr;
}
}
</style>

</head>
<body>

<div class="main">

<div class="topbar">
<h1>Annual Plan</h1>
<span>Kepala Sekolah</span>
</div>

<div class="card">

<h2>Annual Plan</h2>

<div class="content">

<!-- LEFT -->
<div class="left">
<h3>Tahun</h3>

<div class="year-box">
2026 / 2027
</div>

<h4>Fokus Utama:</h4>
<p>
Peningkatan literasi awal,<br>
penguatan sosial emosional,<br>
dan dokumentasi pembelajaran<br>
terintegrasi.
</p>
</div>

<!-- RIGHT -->
<div class="right">

<h3>Target Pengembangan</h3>

<!-- FORM -->
<form method="POST">
<input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">

<input type="text" name="target" placeholder="Target"
value="<?= $edit['target'] ?? '' ?>" required>

<input type="text" name="indikator" placeholder="Indikator"
value="<?= $edit['indikator'] ?? '' ?>" required>

<input type="text" name="waktu" placeholder="Waktu"
value="<?= $edit['waktu'] ?? '' ?>" required>

<button type="submit" name="simpan">
<?= isset($edit) ? 'Update' : 'Tambah' ?>
</button>
</form>

<!-- TABLE -->
<div class="table">

<div class="row header">
<div>Target</div>
<div>Indikator</div>
<div>Waktu</div>
<div>Aksi</div>
</div>

<?php while($row = $data->fetch_assoc()): ?>
<div class="row">
<div class="blue"><?= $row['target'] ?></div>
<div><?= $row['indikator'] ?></div>
<div><?= $row['waktu'] ?></div>

<div>
<a href="?edit=<?= $row['id'] ?>">Edit</a> |
<a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Hapus data?')">Hapus</a>
</div>
</div>
<?php endwhile; ?>

</div>

</div>

</div>

</div>

</div>

</body>
</html>