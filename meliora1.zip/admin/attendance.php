<?php
include "../db.php";
// ================== SIMPAN ==================
if(isset($_POST['simpan'])){
    $nama = $_POST['nama'];
    $status = $_POST['status'];
    $catatan = $_POST['catatan'];
    $tanggal = date('Y-m-d');

    $conn->query("INSERT INTO attendance (nama,status,catatan,tanggal)
                  VALUES ('$nama','$status','$catatan','$tanggal')");
    
    header("Location: attendance.php"); exit;
}

// ================== HAPUS ==================
if(isset($_GET['hapus'])){
    $id = intval($_GET['hapus']);
    $conn->query("DELETE FROM attendance WHERE id=$id");
    header("Location: attendance.php"); exit;
}

// ================== EDIT ==================
$edit = null;
if(isset($_GET['edit'])){
    $id = intval($_GET['edit']);
    $res = $conn->query("SELECT * FROM attendance WHERE id=$id");
    $edit = $res->fetch_assoc();
}

// ================== UPDATE ==================
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $status = $_POST['status'];
    $catatan = $_POST['catatan'];

    $conn->query("UPDATE attendance 
                  SET nama='$nama', status='$status', catatan='$catatan'
                  WHERE id=$id");

    header("Location: attendance.php"); exit;
}

// ================== DATA ==================
$data = $conn->query("SELECT * FROM attendance ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Attendance</title>

<style>
/* CSS kamu (tidak diubah) */
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial;}
body{background:#f4f6fb;}
.container{display:flex;}
.main{flex:1;padding:20px;}
.header{display:flex;justify-content:space-between;margin-bottom:20px;}
.card{background:white;padding:20px;border-radius:15px;}
.card-header{display:flex;justify-content:space-between;margin-bottom:15px;}
.date{color:gray;}
.tabs{margin-bottom:15px;}
.tabs button{padding:8px 15px;border:1px solid #ccc;border-radius:20px;background:#f5f5f5;margin-right:10px;}
.table{width:100%;}
.table-header,.row{
display:grid;
grid-template-columns:50px 2fr 1fr 2fr 1fr;
padding:10px;border-radius:10px;margin-bottom:8px;align-items:center;
}
.table-header{background:#f1f3f9;font-weight:bold;}
.row{background:#f9fafc;}
.badge{padding:5px 12px;border-radius:20px;font-size:12px;}
.hadir{background:#e3f0ff;color:#2f4db6;}
.izin{background:#fff4e5;color:#d97706;}
.sakit{background:#ffe4e6;color:#dc2626;}
.action{text-align:right;margin-top:20px;}
.btn-primary{background:#2f4db6;color:white;padding:10px 20px;border:none;border-radius:10px;}
a{font-size:12px;text-decoration:none;color:#2f4db6;}
input,select{padding:8px;margin:5px;border-radius:8px;border:1px solid #ccc;}
</style>
</head>

<body>

<div class="container">
<div class="main">

<div class="header">
<h1>Attendance</h1>
<span>Kepala Sekolah</span>
</div>

<div class="card">

<div class="card-header">
<h3>Kehadiran Harian</h3>
<span class="date">Tanggal: <?= date('d/m/Y') ?></span>
</div>

<!-- FORM -->
<form method="POST">
<input type="hidden" name="id" value="<?= $edit['id'] ?? '' ?>">

<input type="text" name="nama" placeholder="Nama Siswa"
value="<?= $edit['nama'] ?? '' ?>" required>

<select name="status" required>
<option value="">Pilih Status</option>
<option value="Hadir" <?= ($edit['status'] ?? '')=='Hadir'?'selected':'' ?>>Hadir</option>
<option value="Izin" <?= ($edit['status'] ?? '')=='Izin'?'selected':'' ?>>Izin</option>
<option value="Sakit" <?= ($edit['status'] ?? '')=='Sakit'?'selected':'' ?>>Sakit</option>
</select>

<input type="text" name="catatan" placeholder="Catatan"
value="<?= $edit['catatan'] ?? '' ?>">

<?php if($edit): ?>
<button type="submit" name="update">Update</button>
<?php else: ?>
<button type="submit" name="simpan">Tambah</button>
<?php endif; ?>
</form>

<!-- TABLE -->
<div class="table">

<div class="table-header">
<div>No</div>
<div>Nama</div>
<div>Status</div>
<div>Catatan</div>
<div>Aksi</div>
</div>

<?php $no=1; while($row = $data->fetch_assoc()): ?>
<div class="row">
<div><?= $no++ ?></div>
<div><?= $row['nama'] ?></div>

<div>
<span class="badge 
<?= strtolower($row['status']) ?>">
<?= $row['status'] ?>
</span>
</div>

<div><?= $row['catatan'] ?></div>

<div>
<a href="?edit=<?= $row['id'] ?>">Edit</a> |
<a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
</div>

</div>
<?php endwhile; ?>

</div>

</div>
</div>
</div>

</body>
</html>