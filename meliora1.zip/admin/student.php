<?php
$conn = new mysqli("localhost","root","","db_sekolah");

// ================== SIMPAN CATATAN ==================
if(isset($_POST['simpan'])){
    $student_id = $_POST['student_id'];
    $minggu = $_POST['minggu'];
    $catatan = $_POST['catatan'];

    $conn->query("INSERT INTO student_development (student_id, minggu, catatan)
                  VALUES ('$student_id','$minggu','$catatan')");
    header("Location: student_profile.php?id=".$student_id); exit;
}

// ================== HAPUS CATATAN ==================
if(isset($_GET['hapus'])){
    $id = intval($_GET['hapus']);
    $conn->query("DELETE FROM student_development WHERE id=$id");
    header("Location: student_profile.php"); exit;
}

// ================== DATA SISWA ==================
$student_id = isset($_GET['id']) ? intval($_GET['id']) : 1;

$student = $conn->query("SELECT * FROM student_profile WHERE id=$student_id")->fetch_assoc();

// ================== DATA PERKEMBANGAN ==================
$dev = $conn->query("SELECT * FROM student_development WHERE student_id=$student_id ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Profile</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Segoe UI;}
body{display:flex;background:#f3f5fa;}
.main{flex:1;padding:30px;}
.topbar{display:flex;justify-content:space-between;margin-bottom:20px;}
.card{background:white;border-radius:20px;padding:25px;}
.content{display:flex;gap:25px;}

/* PROFILE */
.profile-box{
width:350px;
border:1px solid #e3e7f2;
border-radius:20px;
padding:20px;
position:relative;
background:white;
}

.photo{
position:absolute;
right:20px;
top:60px;
width:90px;
height:110px;
border:1px solid #ddd;
border-radius:15px;
display:flex;
align-items:center;
justify-content:center;
background:#fafbff;
}

/* DEVELOPMENT */
.development{
flex:1;
border:1px solid #e3e7f2;
border-radius:20px;
padding:20px;
background:white;
}

.week-box{
border:1px solid #e3e7f2;
border-radius:15px;
padding:15px;
margin-bottom:10px;
background:#fafbff;
}

.week-box h4{color:#2f67d8;}

/* FORM */
input,textarea{
width:100%;
padding:10px;
margin:5px 0;
border-radius:10px;
border:1px solid #ddd;
}

button{
background:#2f67d8;
color:white;
padding:10px 20px;
border:none;
border-radius:10px;
cursor:pointer;
}

a{font-size:12px;color:#2f67d8;text-decoration:none;}
</style>

</head>

<body>

<div class="main">

<div class="topbar">
<h1>Student Profile</h1>
<span>Kepala Sekolah</span>
</div>

<div class="card">

<div class="content">

<!-- PROFILE -->
<div class="profile-box">

<h3><?= $student['nama'] ?></h3>

<p><b>Kelas:</b> <?= $student['kelas'] ?></p>
<p><b>Tanggal Lahir:</b> <?= $student['ttl'] ?></p>
<p><b>Wali Murid:</b> <?= $student['wali'] ?></p>

<div class="photo">Foto</div>

</div>

<!-- DEVELOPMENT -->
<div class="development">

<h3>Riwayat Perkembangan</h3>

<!-- FORM TAMBAH -->
<form method="POST">
<input type="hidden" name="student_id" value="<?= $student_id ?>">

<input type="text" name="minggu" placeholder="Minggu (contoh: Minggu 1)" required>

<textarea name="catatan" placeholder="Catatan perkembangan"></textarea>

<button type="submit" name="simpan">Tambah</button>
</form>

<br>

<!-- LIST -->
<?php while($row = $dev->fetch_assoc()): ?>
<div class="week-box">
<h4><?= $row['minggu'] ?></h4>
<p><?= $row['catatan'] ?></p>

<a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
</div>
<?php endwhile; ?>

</div>

</div>

</div>

</div>

</body>
</html>